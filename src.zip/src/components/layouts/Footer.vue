<template>
	<div class="footer">
		<ul style="    visibility: hidden;">
			<li>友情链接：</li>
			<li><a href="">新浪网</a></li>
			<li><a href="">金色财经</a></li>
			<li><a href="">36氪</a></li>
			<li><a href="">猎云网</a></li>
			<li><a href="">币世界</a></li>
			<li><a href="">NRC</a></li>
		</ul>
		<div class="ban">
			版权© 2018 INU -保留所有权利
		</div>
	</div>
</template>

<script>
</script>

<style>
	
</style>