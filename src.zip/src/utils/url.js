//const url = "http://aaa.com";
const url = "http://minsadmin.gksharedmall.com";
export default url;
