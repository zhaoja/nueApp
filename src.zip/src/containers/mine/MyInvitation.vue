<template>
	<div class="mui-content pay-oder">
		<img src="@/assets/images/er.jpg"/>
		<div>邀请亲朋好友加入INU<br/>共同保障健康</div>
	</div>
</template>

<script>
</script>

<style>
</style>