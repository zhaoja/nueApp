<template>
	<div class="myvc">
		<ul class="smooth">
			<li class="smooth-li">
				<div class="inner">
					<div class="inner-header">
						订单号：1803230945032323
					</div>
					<div class="inner-body">
						<ul>
							<li><span>产品名称：</span>健康保障计划                       </li>
							<li><span>投保人：</span>欧阳晓晓                          </li>
							<li><span>交易ID：</span>HSU086789IJNY89P879IOIJH909… </li>
						</ul>
					</div>
					<div class="inner-footer">
						<ul>
							<li>下单时间：2018-01-01  21:23:20 </li>
							<li>生效时间：2018-01-01  21:23:20 </li>
						</ul>
					</div>
				</div>
			</li>
			 
			<li class="smooth-li">
				<div class="inner">
					<div class="inner-header">
						订单号：1803230945032323
					</div>
					<div class="inner-body">
						<ul>
							<li><span>产品名称：</span>健康保障计划                       </li>
							<li><span>投保人：</span>欧阳晓晓                          </li>
							<li><span>交易ID：</span>HSU086789IJNY89P879IOIJH909… </li>
						</ul>
					</div>
					<div class="inner-footer">
						<ul>
							<li>下单时间：2018-01-01  21:23:20 </li>
							<li>生效时间：2018-01-01  21:23:20 </li>
						</ul>
					</div>
				</div>
			</li>
		</ul>
	</div>
</template>

<script>
</script>

<style>
</style>