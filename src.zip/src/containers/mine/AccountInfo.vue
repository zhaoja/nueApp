<template>
	<div>
		<ul class="mui-table-view">
			<li class="mui-table-view-cell">
				<a class="mui-navigate-right">
					头像
					<img src="@/assets/images/my.png" class="mui-media-object mui-pull-right"/>
				</a>
			</li>
			<li class="mui-table-view-cell">
				<a class="mui-navigate-right" href="#/newpd">
					修改密码
				</a>
			</li>
		</ul>
	</div>
</template>

<script>
</script>

<style>
</style>