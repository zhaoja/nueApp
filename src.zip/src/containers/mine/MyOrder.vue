<template>
	<div class="myOd">
		<ul class="smooth">
			<li class="smooth-li">
				<div class="inner">
					<div class="inner-header">
						订单号：1803230945032323
						<span></span>
					</div>
					<div class="inner-body">
						<ul>
							<li><span>产品名称：</span>健康保障计划                       </li>
							<li><span>投保人：</span>欧阳晓晓                          </li>
						</ul>
					</div>
					<div class="inner-footer">
						<ul>
							<li>下单时间：2018-01-01  21:23:20 </li>
							<li>生效时间：2018-01-01  21:23:20 </li>
						</ul>
						<div class="btnlist">
							<button>取消订单</button>
					 		<button>立即支付</button>
						</div>
					</div>
				</div>
			</li>
		</ul>
	</div>
</template>

<script>
</script>

<style>
</style>