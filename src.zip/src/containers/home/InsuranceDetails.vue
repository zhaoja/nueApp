<template>
	<div class="insuranceDetails">
		<div class="inD1">
			<img class="bannerImg" :src="InsuranceDetails.insurance_logo"/>
		    <div class="mui-row">
		        <div class="num">
		        	资金池总额(元) 
				</div>	
		        <div class="num">
		         <span class="mui-badge-danger mui-badge-inverted">{{InsuranceDetails.all_money}}</span>
		        </div>	
		        <div class="num">
		        	加入计划总人数(人) 
		        	<div>
			           <span class="mui-badge-danger mui-badge-inverted">{{InsuranceDetails.all_user_buy}}</span>
			        </div>
		        </div>
		        <div class="num">
		        	近7日加入计划人数(人) 
		        	<div>
			           <span class="mui-badge-danger mui-badge-inverted">{{InsuranceDetails.seven_user_buy}}</span>
			        </div>
		        </div>
		    </div>
		</div>
 
		<div class="mui-card">
			<div class="title1">计划规则</div>
			<ul class="mui-table-view">
				<li class="mui-table-view-cell">
					加入年龄
					<select v-model="pay">
						<option v-for="am in InsuranceDetails.age_money" :value="am.insured_amount">{{am.age}}</option>
					</select>
				</li>
				<li class="mui-table-view-cell">
					保障范围
					<span>{{InsuranceDetails.insurance_range}}</span>
				</li>
				<li class="mui-table-view-cell">
					保障期间
					<span>
					 {{InsuranceDetails.insurance_time}}年
				</span>
				</li>
				<li class="mui-table-view-cell">
					赔付金额
					<span>
						最高{{InsuranceDetails.insurance_max_money}}元
					</span>
				</li>
			</ul>
		</div>

		<div class="mui-card">
			<div class="title1">计划简介</div>
			<div class="mui-card-content">
				<div class="mui-card-content-inner">
					<p v-html="InsuranceDetails.synopsis"></p>
				</div>
			</div>
		</div>
		
		<div class="mui-card">
			<div class="title1">赔付流程</div>
			<div class="mui-card-content">
				<div class="mui-card-content-inner">
					<p v-html="InsuranceDetails.procedure"></p>
				</div>
			</div>
		</div>
		
		<div class="mui-card">
			<div class="title1">常见问题</div>
			<div class="mui-card-content">
				<div class="mui-card-content-inner">
					<div class="title2">Q：什么是重疾险产品？</div>	
					<p>
						A：“INU生命互助”是全球首家采用实名制区块链以及人工智能技术，整合传统保险行业中投保人以及未投保人需要解决的基础痛点，建立了一个完整的体系。
					</p>
					<div class="title2">Q：什么是重疾险产品？</div>	
					<p>A：“INU生命互助”是全球首家采用实名制区块链以及人工智能技术，整合传统保险行业中投保人以及未投保人需要解决的基础痛点，建立了一个完整的体系。					</p>
				</div>
			</div>
		</div>
		<div class="inD6">
			需支付INU <span> {{pay}}</span>
			<button class="mui-btn mui-btn-warning" @click="gotoDetails(InsuranceDetails.id,pay)">立即加入</button>
		</div>
		 
	</div>
</template>

<script>
	import { mapState } from "vuex"
	
	export default {
//		name: 'home',
		data(){
			return{
				pay:""
			}
		},
		computed: {
			...mapState({
				InsuranceDetails:state => state.insuranceDetails.InsuranceDetails
//				InsuranceDetails:state => state.InsuranceDetails, 
//				insureData:state => state.home.homeData.insureData,
			})
		},
		created(){
			
//			this.$store.dispatch("getTitle","")
			this.$store.dispatch("getInsuranceDetails",this.$route.params.id)
 			
		},
		methods:{
			gotoDetails(id,money){
//				this.$router.push({ path: `/insuranceDetails/${id}` })
				this.$router.push({ path: `/insure/${id}/${money}`})
			},
			payInu(n){
				console.log(1)
			}
		},
		mounted(){
//			console.log(this.InsuranceDetails.age_money[0].insured_amount)
//		 	this.pay = this.InsuranceDetails.age_money[0].insured_amount;
			var slider = this.mui("#slider");
			slider.slider({
				interval: 5000
			});
		
		}
	}
</script>

<style scoped>
	.mui-table-view-cell span,
	.mui-table-view-cell .mui-numbox {
		float: right;
	}
</style>