//import $http from '../utils/http.js';
//import HtmlUtil from '../utils/HtmlUtil.js';
//const url = "http://minsadmin.gksharedmall.com";
	const url = 'http://aaa.com'

//用户注册和登录
export default {
	state: {
		userInfo:{
			phone:"",	//电话
			verifiyCode:"",	//验证码
			password:"", //密码
			repassword:"", //确认密码
			uid:'',  //用户id
 
		}
	},
	actions: {
		newUser({ commit, state },param){
			commit("newUserSuccess", param)
		}
	},
	mutations: {
		 newUserSuccess(state, ndata){
		 	console.log(ndata,2)
		 	state.userInfo.uid = ndata;
		 }
	}
	
}